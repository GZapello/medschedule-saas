import { BookingLinkCard } from '../public-booking/BookingLinkSettings';
import React, { useState, useEffect, useRef } from 'react';
import { ApiClient } from '../../api/client';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import { Professional, Profession, Specialty } from '../../types';
import {
  UserCog,
  Plus,
  Clock,
  Calendar,
  Shield,
  Ban,
  X,
  CheckCircle2,
  Mail,
  Phone,
  Edit3,
  Share2,
  Link,
  Wallet,
  DollarSign,
  AlertTriangle,
  Copy
} from 'lucide-react';
import { formatDoctorName } from '../../utils/formatters';

const getCouncilForProfession = (prof?: Profession | null, profNameOrId?: string): string => {
  if (prof?.registration_board_label) return prof.registration_board_label;
  if ((prof as any)?.boardLabel) return (prof as any).boardLabel;
  const target = `${prof?.name || ''} ${prof?.slug || ''} ${profNameOrId || ''}`.toLowerCase();
  if (target.includes('dentist') || target.includes('odonto')) return 'CRO';
  if (target.includes('médic') || target.includes('medic')) return 'CRM';
  if (target.includes('fisioterap') || target.includes('fisio')) return 'CREFITO';
  if (target.includes('psicanal')) return 'Registro Associação';
  if (target.includes('psicólog') || target.includes('psicolog')) return 'CRP';
  if (target.includes('nutri')) return 'CRN';
  if (target.includes('fono')) return 'CRFa';
  if (target.includes('ocupacional')) return 'CREFITO';
  if (target.includes('psicopedag')) return 'ABPp';
  if (target.includes('personal') || target.includes('educa')) return 'CREF';
  if (target.includes('enferm')) return 'COREN';
  if (target.includes('farmac')) return 'CRF';
  if (target.includes('biomedic')) return 'CRBM';
  if (target.includes('social')) return 'CRESS';
  if (target.includes('administra') || target.includes('gestor')) return 'CRA';
  return 'Conselho';
};

export const ProfessionalsView: React.FC = () => {
  const { showToast } = useToast();
  const { reloadSession, currentTenant, isClinicAdmin } = useAuth();
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [professions, setProfessions] = useState<Profession[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Controle de alteração única de profissão (Item 2)
  const [isProfessionUnlocked, setIsProfessionUnlocked] = useState<boolean>(false);
  const [showConfirmChangeModal, setShowConfirmChangeModal] = useState<boolean>(false);
  const professionSelectRef = useRef<HTMLSelectElement>(null);

  // Modal Editar Profissional
  const [editingProf, setEditingProf] = useState<Professional | null>(null);
  const [editName, setEditName] = useState<string>('');
  const [editGender, setEditGender] = useState<'M' | 'F'>('M');
  const [editProfessionId, setEditProfessionId] = useState<string>('');
  const [editSpecialtyId, setEditSpecialtyId] = useState<string>('');
  const [editSpecialtyName, setEditSpecialtyName] = useState<string>('');
  const [editRegistrationType, setEditRegistrationType] = useState<string>('CRP');
  const [editRegistrationNumber, setEditRegistrationNumber] = useState<string>('');
  const [editBio, setEditBio] = useState<string>('');
  const [editPracticeAreas, setEditPracticeAreas] = useState<string>('');
  const [editBufferMinutes, setEditBufferMinutes] = useState<number>(10);
  const [editSlug, setEditSlug] = useState<string>('');
  const [editPublicBookingEnabled, setEditPublicBookingEnabled] = useState<boolean>(true);
  const [editRemunerationType, setEditRemunerationType] = useState<'commission' | 'salary' | 'both'>('commission');
  const [editCommissionPercentage, setEditCommissionPercentage] = useState<number>(0);
  const [editFixedSalary, setEditFixedSalary] = useState<number>(0);
  const [editPaymentDay, setEditPaymentDay] = useState<number>(5);

  const handleCopyBookingLink = async (prof: Professional) => {
    if (prof.public_booking_enabled !== 1 || !prof.slug || !currentTenant?.slug) { showToast('O link público deste profissional está indisponível.', 'info'); return; }
    const url = `${window.location.origin}/agendar/${currentTenant.slug}/${prof.slug}`;
    try { await navigator.clipboard.writeText(url); showToast('Link de agendamento copiado.', 'success'); }
    catch { showToast('Não foi possível copiar o link.', 'error'); }
  };

  // Modal Bloqueio de Horário
  const [showBlockModal, setShowBlockModal] = useState<boolean>(false);
  const [blockProfId, setBlockProfId] = useState<string>('');
  const [blockTitle, setBlockTitle] = useState<string>('');
  const [blockStart, setBlockStart] = useState<string>('');
  const [blockEnd, setBlockEnd] = useState<string>('');
  const [blockType, setBlockType] = useState<string>('absence');

  const fetchData = async () => {
    try {
      setLoading(true);
      const [profs, taxonomyProfs, taxonomySpecs] = await Promise.all([
        ApiClient.get<Professional[]>('/v1/professionals'),
        ApiClient.get<Profession[]>('/v1/taxonomy/professions'),
        ApiClient.get<Specialty[]>('/v1/taxonomy/specialties')
      ]);
      setProfessionals(profs);
      setProfessions(taxonomyProfs);
      setSpecialties(taxonomySpecs);
    } catch (err: any) {
      showToast('Erro ao carregar equipe de profissionais', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveEditProfessional = async () => {
    if (!editingProf || !editName) {
      showToast('Nome é obrigatório', 'error');
      return;
    }

    try {
      await ApiClient.put(`/v1/professionals/${editingProf.id}`, {
        name: editName,
        gender: editGender,
        professionId: editProfessionId,
        specialtyId: editSpecialtyId || null,
        specialtyName: editSpecialtyName.trim(),
        specialtyCustom: editSpecialtyName.trim(),
        registrationType: editRegistrationType || null,
        registrationNumber: editRegistrationNumber || null,
        bio: editBio || null,
        practiceAreas: editPracticeAreas || null,
        bufferMinutes: Number(editBufferMinutes),
        slug: editSlug.trim() || null,
        ...(isClinicAdmin ? { publicBookingEnabled: editPublicBookingEnabled } : {}),
        remunerationType: editRemunerationType,
        commissionPercentage: Number(editCommissionPercentage),
        fixedSalary: Number(editFixedSalary),
        paymentDay: Number(editPaymentDay)
      });

      showToast('Profissional atualizado com sucesso!', 'success');
      setIsProfessionUnlocked(false);
      setShowConfirmChangeModal(false);
      setEditingProf(null);
      await reloadSession();
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'Erro ao atualizar profissional', 'error');
    }
  };

  const handleConfirmUnlockProfession = () => {
    setShowConfirmChangeModal(false);
    setIsProfessionUnlocked(true);
    setTimeout(() => {
      if (professionSelectRef.current) {
        professionSelectRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
        professionSelectRef.current.focus();
      }
    }, 100);
  };

  const handleCloseEditModal = () => {
    setEditingProf(null);
    setIsProfessionUnlocked(false);
    setShowConfirmChangeModal(false);
  };

  const handleCreateBlock = async () => {
    if (!blockTitle || !blockStart || !blockEnd) {
      showToast('Preencha título, início e término do bloqueio', 'error');
      return;
    }

    try {
      await ApiClient.post('/v1/professionals/blocks', {
        professionalId: blockProfId || null,
        title: blockTitle,
        startDatetime: blockStart,
        endDatetime: blockEnd,
        type: blockType
      });

      showToast('Bloqueio de agenda registrado!', 'success');
      setShowBlockModal(false);
      setBlockTitle('');
      setBlockStart('');
      setBlockEnd('');
    } catch (err: any) {
      showToast(err.message || 'Erro ao criar bloqueio', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-4 sm:p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Equipe de Profissionais</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Cadastre os profissionais, defina especialidades, regras de remuneração, escala e links de agendamento online.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => setShowBlockModal(true)}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-xl transition-all border border-amber-200 cursor-pointer min-h-[40px]"
          >
            <Ban className="w-4 h-4" /> Bloquear Horário / Férias
          </button>
        </div>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {professionals.map(p => (
          <div key={p.id} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-start justify-between">
                <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-700 font-extrabold text-xl flex items-center justify-center">
                  {p.name.charAt(0)}
                </div>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Ativo
                </span>
              </div>

              <div className="mt-3">
                <h3 className="font-bold text-slate-900 text-base">
                  {formatDoctorName(p.name, (p as any).gender)}
                </h3>
                <p className="text-xs text-indigo-600 font-semibold">{p.specialty_name || p.profession_name}</p>
                {p.registration_number && (
                  <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                    {p.registration_type}: {p.registration_number}
                  </p>
                )}
              </div>

              {p.bio && (
                <p className="text-xs text-slate-500 mt-2 line-clamp-3 leading-relaxed">
                  {p.bio}
                </p>
              )}

              {p.practice_areas && (
                <div className="mt-2 p-2 bg-indigo-50/60 rounded-xl border border-indigo-100 text-[11px] text-slate-700">
                  <span className="font-bold text-indigo-700 block text-[10px]">Atendimentos e áreas de atuação:</span>
                  <span className="leading-snug">{p.practice_areas}</span>
                </div>
              )}

              {/* Informações de Remuneração e Link Público */}
              <div className="mt-3 pt-3 border-t border-slate-100 space-y-1 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="text-[11px] text-slate-400">Remuneração:</span>
                  <span className="font-semibold text-slate-700">
                    {p.remuneration_type === 'salary'
                      ? `Fixo: R$ ${Number(p.fixed_salary || 0).toFixed(2)}`
                      : p.remuneration_type === 'both'
                      ? `${p.commission_percentage || 0}% + R$ ${Number(p.fixed_salary || 0).toFixed(2)}`
                      : `${p.commission_percentage || 0}% de comissão`}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs text-slate-500">
              <button
                type="button"
                onClick={() => handleCopyBookingLink(p)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl transition-all shadow-2xs cursor-pointer text-xs"
                title="Copiar link público individual do profissional para agendamento"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Copiar link</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setEditingProf(p);
                  setIsProfessionUnlocked(false);
                  setShowConfirmChangeModal(false);
                  setEditName(p.name);
                  setEditGender((p as any).gender || 'M');
                  const currentPProfId = p.profession_id || (professions[0]?.id || '');
                  setEditProfessionId(currentPProfId);
                  setEditSpecialtyId(p.specialty_id || '');
                  setEditSpecialtyName(p.specialty_name || (p as any).specialty_custom || '');
                  setEditRegistrationType(p.registration_type || 'CRM');
                  setEditRegistrationNumber(p.registration_number || '');
                  setEditBio(p.bio || '');
                  setEditPracticeAreas(p.practice_areas || '');
                  setEditBufferMinutes(p.buffer_minutes || 10);
                  setEditSlug(p.slug || '');
                  setEditPublicBookingEnabled(p.public_booking_enabled !== 0);
                  setEditRemunerationType(p.remuneration_type || 'commission');
                  setEditCommissionPercentage(p.commission_percentage || 0);
                  setEditFixedSalary(p.fixed_salary || 0);
                  setEditPaymentDay(p.payment_day || 5);
                }}
                className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl transition-all shadow-2xs cursor-pointer text-xs"
              >
                <Edit3 className="w-3.5 h-3.5" /> Editar
              </button>
            </div>
          </div>
        ))}
      </div>



      {/* Modal Editar Profissional */}
      {editingProf && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto mobile-modal">
          <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-lg font-bold text-slate-900">Editar Profissional: {editingProf.name}</h3>
              <button aria-label="Fechar" onClick={handleCloseEditModal} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Nome Completo *</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={e => setEditName(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Sexo / Prefixo *</label>
                  <select
                    value={editGender}
                    onChange={e => setEditGender(e.target.value as 'M' | 'F')}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-slate-50 font-semibold"
                  >
                    <option value="M">Masculino (Dr.)</option>
                    <option value="F">Feminino (Dra.)</option>
                  </select>
                </div>
              </div>

              {/* Estrutura: Profissão -> Especialidade -> Atendimentos/áreas de atuação livres */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-semibold text-slate-700">Profissão *</label>
                    {isProfessionUnlocked && (
                      <span className="text-[10px] text-amber-800 font-bold bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                        🔓 Liberada para alteração
                      </span>
                    )}
                  </div>
                  <select
                    ref={professionSelectRef}
                    value={editProfessionId}
                    disabled={!isProfessionUnlocked}
                    onChange={e => {
                      const newPId = e.target.value;
                      setEditProfessionId(newPId);
                      setEditSpecialtyName('');
                      const matching = specialties.filter(s => s.profession_id === newPId || (s as any).professionId === newPId);
                      setEditSpecialtyId(matching.length > 0 ? matching[0].id : '');
                      const selProf = professions.find(p => p.id === newPId);
                      setEditRegistrationType(getCouncilForProfession(selProf, newPId));
                    }}
                    className={`w-full border rounded-xl px-3 py-2 text-xs font-semibold transition-all ${
                      isProfessionUnlocked
                        ? 'border-amber-400 bg-amber-50 text-slate-900 ring-2 ring-amber-400 shadow-xs focus:ring-amber-500 focus:border-amber-500'
                        : 'border-slate-200 bg-slate-100 text-slate-500 cursor-not-allowed opacity-85'
                    }`}
                  >
                    {professions.map(p => (
                      <option key={p.id} value={p.id}>{p.label || p.name}</option>
                    ))}
                  </select>

                  {/* Controle de alteração única de profissão */}
                  {!Boolean(editingProf.profession_change_used) && !isProfessionUnlocked && (
                    <button
                      type="button"
                      onClick={() => setShowConfirmChangeModal(true)}
                      className="mt-1.5 text-[11px] text-amber-600 hover:text-amber-700 hover:underline font-medium inline-flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <AlertTriangle className="w-3 h-3 text-amber-500" />
                      <span>Errei minha profissão, preciso alterar</span>
                    </button>
                  )}

                  {isProfessionUnlocked && (
                    <div className="mt-1.5 p-2 bg-amber-50 border border-amber-300/80 rounded-lg text-[10px] text-amber-800 font-medium leading-tight space-y-0.5">
                      <p className="font-bold flex items-center gap-1">
                        ⚠️ Atenção: alteração única
                      </p>
                      <p>A nova profissão escolhida será bloqueada permanentemente assim que você clicar em "Salvar Alterações".</p>
                    </div>
                  )}

                  {Boolean(editingProf.profession_change_used) && (
                    <p className="mt-1 text-[10px] text-slate-400">
                      A alteração única de profissão já foi utilizada para este profissional.
                    </p>
                  )}
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-semibold text-slate-700">Especialidade(s)</label>
                    <span className="text-[10px] text-indigo-600 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded">Texto livre</span>
                  </div>
                  <input
                    type="text"
                    value={editSpecialtyName}
                    onChange={e => setEditSpecialtyName(e.target.value)}
                    placeholder="Ex: Cardiologia Clínica, Arritmia..."
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-slate-50 font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-semibold text-slate-700">Atendimentos e áreas de atuação</label>
                  <span className="text-[10px] text-slate-400 font-medium">Texto livre</span>
                </div>
                <textarea
                  rows={2}
                  value={editPracticeAreas}
                  onChange={e => setEditPracticeAreas(e.target.value)}
                  placeholder="Ex: TEA, TDAH, Ansiedade, Depressão, Orientação de Pais, Avaliação Neuropsicológica..."
                  className="w-full border border-slate-200 rounded-xl p-2.5 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tipo de Registro</label>
                  <input
                    type="text"
                    value={editRegistrationType}
                    onChange={e => setEditRegistrationType(e.target.value)}
                    placeholder="Ex: CRP, CRM, OAB"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Número do Registro</label>
                  <input
                    type="text"
                    value={editRegistrationNumber}
                    onChange={e => setEditRegistrationNumber(e.target.value)}
                    placeholder="Ex: 06/12345"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Biografia / Apresentação</label>
                <textarea
                  rows={2}
                  value={editBio}
                  onChange={e => setEditBio(e.target.value)}
                  placeholder="Breve currículo exibido na página pública..."
                  className="w-full border border-slate-200 rounded-xl p-2.5 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Intervalo entre consultas (Buffer em minutos)</label>
                <input
                  type="number"
                  min={0}
                  max={60}
                  value={editBufferMinutes}
                  onChange={e => setEditBufferMinutes(Number(e.target.value))}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs"
                />
              </div>

              {/* Seção Regras de Remuneração e Repasse */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span className="font-bold text-slate-900 text-xs">Regras de Remuneração e Pagamento</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Modalidade *</label>
                    <select
                      value={editRemunerationType}
                      onChange={e => setEditRemunerationType(e.target.value as any)}
                      className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-white font-medium"
                    >
                      <option value="commission">Apenas Comissão (%)</option>
                      <option value="salary">Apenas Salário Fixo (R$)</option>
                      <option value="both">Salário Fixo + Comissão</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Dia do Pagamento</label>
                    <input
                      type="number"
                      min={1}
                      max={31}
                      value={editPaymentDay}
                      onChange={e => setEditPaymentDay(Number(e.target.value))}
                      placeholder="Ex: 5"
                      className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-white font-medium"
                    />
                  </div>
                </div>

                {(editRemunerationType === 'commission' || editRemunerationType === 'both') && (
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Comissão sobre Consultas / Procedimentos (%)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step={0.5}
                      value={editCommissionPercentage}
                      onChange={e => setEditCommissionPercentage(Number(e.target.value))}
                      placeholder="Ex: 50"
                      className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-white font-medium"
                    />
                  </div>
                )}

                {(editRemunerationType === 'salary' || editRemunerationType === 'both') && (
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Salário Fixo Mensal (R$)</label>
                    <input
                      type="number"
                      min={0}
                      step={50}
                      value={editFixedSalary}
                      onChange={e => setEditFixedSalary(Number(e.target.value))}
                      placeholder="Ex: 3500.00"
                      className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-white font-medium"
                    />
                  </div>
                )}
              </div>

              <BookingLinkCard title={`Página individual — ${editName}`} enabled={editPublicBookingEnabled} url={editingProf?.slug && currentTenant?.slug ? `${window.location.origin}/agendar/${currentTenant.slug}/${editingProf.slug}` : null} onToggle={isClinicAdmin ? setEditPublicBookingEnabled : undefined} />

              <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleCloseEditModal}
                  className="w-full sm:w-auto px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl min-h-[40px]"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleSaveEditProfessional}
                  className="w-full sm:w-auto px-6 py-2 font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs min-h-[40px]"
                >
                  Salvar Alterações
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação: Alteração Única de Profissão (Item 2) */}
      {showConfirmChangeModal && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto mobile-modal">
          <div className="bg-white rounded-3xl max-w-md w-full p-4 sm:p-6 shadow-2xl border border-amber-200 animate-in zoom-in-95 duration-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center gap-3 text-amber-600">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Alterar Profissão Cadastrada</h3>
                <p className="text-xs text-slate-500">Recurso de uso único por profissional</p>
              </div>
            </div>

            <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-3.5 text-xs text-amber-900 space-y-2 leading-relaxed">
              <p className="font-semibold">
                Esta alteração só pode ser feita uma única vez durante toda a existência da conta.
              </p>
              <p className="text-slate-600 text-[11px]">
                Ao confirmar, o campo de profissão será liberado para correção agora. Após salvar as alterações, a profissão ficará <strong>permanentemente bloqueada</strong> para novas edições e o módulo profissional será atualizado automaticamente pelo sistema.
              </p>
            </div>

            <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowConfirmChangeModal(false)}
                className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-all cursor-pointer min-h-[40px]"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmUnlockProfession}
                className="w-full sm:w-auto px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 min-h-[40px]"
              >
                Sim, quero alterar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Bloqueio de Horário */}
      {showBlockModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto mobile-modal">
          <div className="bg-white rounded-3xl max-w-md w-full p-4 sm:p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-lg font-bold text-slate-900">Bloquear Agenda / Ausência</h3>
              <button aria-label="Fechar" onClick={() => setShowBlockModal(false)} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Profissional</label>
                <select
                  value={blockProfId}
                  onChange={e => setBlockProfId(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs bg-slate-50 min-h-[38px]"
                >
                  <option value="">Toda a Clínica (Recesso Geral)</option>
                  {professionals.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Motivo do Bloqueio *</label>
                <input
                  type="text"
                  value={blockTitle}
                  onChange={e => setBlockTitle(e.target.value)}
                  placeholder="Ex: Férias, Reunião de Equipe, Consulta Médica"
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Início (Data e Hora) *</label>
                  <input
                    type="datetime-local"
                    value={blockStart}
                    onChange={e => setBlockStart(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs min-h-[38px]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Término *</label>
                  <input
                    type="datetime-local"
                    value={blockEnd}
                    onChange={e => setBlockEnd(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs min-h-[38px]"
                  />
                </div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  onClick={() => setShowBlockModal(false)}
                  className="w-full sm:w-auto px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl min-h-[40px]"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleCreateBlock}
                  className="w-full sm:w-auto px-6 py-2 font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs min-h-[40px]"
                >
                  Salvar Bloqueio
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
